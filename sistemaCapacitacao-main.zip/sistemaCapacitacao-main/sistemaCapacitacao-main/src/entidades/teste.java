package entidades;

public class teste {
}
