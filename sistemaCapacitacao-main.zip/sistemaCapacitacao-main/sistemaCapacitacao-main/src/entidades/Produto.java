package entidades;

import javax.swing.*;

public class Produto {
    public static void valorTotal(int quantProduto, double preço) {
        double Vtotal = quantProduto * preço;
        JOptionPane.showMessageDialog(null, "O valor total do estoque é: R$:"+Vtotal);
    }
    public static double entEst(int quantProduto){
        int nvEnt = Integer.parseInt(JOptionPane.showInputDialog("digite a quantidade de produtos que entrarão no estoque"));
        quantProduto = quantProduto + nvEnt;
        JOptionPane.showMessageDialog(null,"a quantidade atualizada é: "+quantProduto);
        return quantProduto;
    }
    public static double saiEst(int quantProduto){
        int nvEnt = Integer.parseInt(JOptionPane.showInputDialog("digite a quantidade de produtos que sairão no estoque"));
        quantProduto = quantProduto - nvEnt;
        JOptionPane.showMessageDialog(null,"a quantidade atualizada é: "+quantProduto);
        return quantProduto;
    }
    public static void menu(){
        String nomeDoProduto = JOptionPane.showInputDialog("diga o nome de seu produto: ");
        int quantProduto = Integer.parseInt(JOptionPane.showInputDialog("diga a quantidade de seu produto: "));
        double preço = Double.parseDouble(JOptionPane.showInputDialog("diga o preço de seu produto: "));

        boolean continuar = true;
        while(continuar){
            int EU = Integer.parseInt(JOptionPane.showInputDialog("Dados do Produto: \n"+
                    "Nome: "+ nomeDoProduto
                    +"\nQuantidade em estoque: "+ quantProduto
                    +"\nPreço dele: R$"+preço
                    +"\n"
                    +"Digite 1 se quiser saber o valor total:"
                    +"\nDigite 2 se quiser adicionar um produto no estoque:"
                    +"\nDigite 3 se quiser saber o valor total:"
                    +"\nDigite 4 se quiser fechar o programa:"
            ));
            if (EU == 1) {
                valorTotal( quantProduto, preço);
            } else if (EU == 2) {
                entEst(quantProduto);
            } else if (EU == 3) {
                saiEst(quantProduto);
            } else if (EU == 4) {
                continuar = false;
            }
        }
    }
}
